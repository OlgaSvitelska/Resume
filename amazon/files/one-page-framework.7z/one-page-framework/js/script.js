

$(document).ready(function(){


	main_path='?route=';

    var init = true, 
        state = window.history.pushState !== undefined;
            
    var handler = function(data) {

		$('.section').html(data.view);
		$('#header').html(data.header);		
 
    };
			

	$.address.state('').init(function() {

		$('.ajax').address();

	}).change(function(event) {

		handling(event)
	
	}); 


	function handling(event){

		if(event.pathNames.length>0){

		
				url='';
				for (var i=1; i<event.pathNames.length; i++) {
					if(i>1) s='/'; else s='';
					url+=s+event.pathNames[i];

				}
				if(url=='') url='main';
				url=main_path+url;

				if(event.queryString!='') url+='&'+event.queryString;

				a={};
				a.address=true;
				if(url=='') url='main';

				get( url, a, function(data){

					if(typeof data.href_url !== "undefined") {
						window.location.href = data.href_url;
					}
					
					if(typeof data.address_url !== "undefined"){

						$.address.value(data.address_url);
					
					}else{
						handler(data);
					}
				});


		}
	}
	


	$('body').on('submit', 'form', function(e){

		var postData = $(this).serializeArray();
		var formURL = $(this).attr("action");
		e.preventDefault(); 
		
		arr={};
		for (var i=0;i<postData.length;i++){ 
			name=postData[i]['name'];
			val=postData[i]['value'];

			if(typeof arr[name] === "undefined") {
				arr[name]={};
				j=0;
			}

			arr[name][j]=val;
			j++;
		}


		formURL=main_path+formURL+'&post=true';
	
		$.ajax(
		{
			url : formURL,
			type: "POST",
			data : arr,
			success:function(data) 
			{
				console.log(data);
				json_obj = JSON.parse(data);
				
				if(!json_obj.succ)	{
					jAlert('Error', json_obj.error)
				}else{
					$('#header').html(json_obj.header);
					$.address.value(json_obj.url); 
				}
			   
			},
			error: function(){
				jAlert('Error', 'Error 404')
			}
		});

		e.preventDefault(); 
	});
	 
 
 
	function get(url, a, callback){

		$.ajax({

			type:"GET",
			data:{a:a},
			url:url,
			success:function(data){
				console.log(data);
					json_obj = JSON.parse(data);


					if(!json_obj.succ)	{
						jAlert('Error', json_obj.error)
					}else{
						callback(json_obj.data);
					}

			},
			error: function() {
				jAlert('Error', 'Error 404')
			 
			}

		});
	
	}
	



});