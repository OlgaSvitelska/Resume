<?php

class Model
{
	private $reg;
	
	function __construct($reg)
	{

		$this->reg=$reg;
	}


	
}