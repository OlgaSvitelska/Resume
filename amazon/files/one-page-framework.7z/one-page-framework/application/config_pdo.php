<?php

$host='mysql:host=127.0.0.1;dbname=project';
$user='root';
$passw='crewpsia1';

?>