<div class="form-registration">
	<div class="registration-group">	
		<form role="form" action="registration/handling">
	        <h4 class="form-signin-heading">Registration</h4>
	       	<input class="form-control" type="email" name="email" placeholder="Email">
	       	<input class="form-control" type="name" name="name" placeholder="Name">
	       	<input class="form-control" type="lname" name="lname" placeholder="Last Name">
			<input class="form-control" name="password" type="password" placeholder="Password">
			<input class="form-control" name="confirm_password" type="password" placeholder="Confirm Password">
			<input class="btn btn-default btn-success uppercase btn_pad" type="submit" name="submit" value="Register">
	        
		</form>
	</div>

</div>

	