<form class="navbar-form navbar-right" action="signin/handling"  role="form">
	<div class="form-group">
		<input type="text" name="email" placeholder="Email" class="form-control">
	</div>
	<div class="form-group">
		<input type="password" name="password" placeholder="Password" class="form-control">
	</div>
	<button type="submit" class="btn btn-success">Sign in</button>
</form>
