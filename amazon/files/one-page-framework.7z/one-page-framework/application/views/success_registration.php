<div class="alert alert-success">
      <strong>Well done!</strong> You successfully registrated.
	</div>