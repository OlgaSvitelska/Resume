<form class="navbar-form navbar-right" action="signin/signout" role="form">
	<button type="submit" class="btn btn-success">Sign Out</button>
</form>	
<div class="user_name pull-right"> Hi, <?=$this['data_user']['name']?></div>
