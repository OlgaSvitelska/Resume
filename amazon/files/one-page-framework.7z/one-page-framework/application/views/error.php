<div class="error">
<?php

echo $this->reg['error'];

?>

</div>