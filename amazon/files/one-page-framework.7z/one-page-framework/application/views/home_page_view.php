<div class="jumbotron">
      <div class="container">
        <h1>Hello!</h1>
        <p>This is a simple ajax-MVC framework. </p>
        <p>
        	<a href="<?=PATH.'registration'?>" class="ajax btn btn-primary btn-lg" role="button">Registration »</a>
        	<a href="<?=PATH.'signin'?>" class="ajax btn btn-primary btn-lg" role="button">Sign In »</a>
        	<a href="<?=PATH.$this->reg['href_linkedin'];?>" class="ajax btn btn-primary btn-lg" role="button">LinkedIn Sign In »</a>
        </p>
      </div>
</div>
