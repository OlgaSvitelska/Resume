<form class="form-signin" action="signin/handling" role="form">
        <h2 class="form-signin-heading">Please sign in</h2>
       
		<input class="form-control" type="email" name="email" placeholder="Email">
		<input class="form-control" name="password" type="password" placeholder="Password">
		<input class="btn btn-default btn-success uppercase btn_pad" type="submit" name="submit" value="Register">
</form>


	