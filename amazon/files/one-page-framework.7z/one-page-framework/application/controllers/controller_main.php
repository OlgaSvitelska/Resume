<?php

class Controller_Main extends Controller
{

	function action_index(){	

		if(isset($this->reg['address'])){
			$in = $this->reg['login']->linked_in('signin/linkedin');

			if(isset($in['url_linkedin'])){
				$this->reg->success(array('href_url'=>$in['url_linkedin']));
			}else{
				$this->view->show_content('home_page_view', true);
			}
			
		}else{
			$this->view->show_template('loading');
		}

	}
	
		
}
