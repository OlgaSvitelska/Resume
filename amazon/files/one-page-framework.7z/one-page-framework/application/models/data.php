<?php class Data{

		private $reg;

		function __construct($reg){
			$this->reg=$reg;
		} 
	
		function get_language( $language){
			$path=MAIN_PATH.'application'.DIRSEP.'languages'.DIRSEP;

			if ($language=='en'){
				include $path.'english.php';
			}elseif($language=='ru'){
				include $path.'russian.php';
			}else{
				echo'error language settings';
			}
		}	

		function error($val){
			$arr['1']="";
			return $arr[$val];
		}
	
	

	}
?>
